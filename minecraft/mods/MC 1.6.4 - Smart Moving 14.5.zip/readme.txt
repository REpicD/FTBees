================
Smart Moving Mod
================

Version 14.5 for Minecraft Client 1.6.4

by Divisor



Description
===========

The Smart moving mod provides various additionaly moving possibilities:

* Climbing only via gaps in the walls
* Climbing ladders with different speeds depending on ladder coverage and/or neighbour blocks
* Alternative animations for flying and falling
* Climbing along ceilings and up vines
* Jumping up & back while climbing
* Configurable sneaking
* Alternative swimming
* Alternative diving
* Alternative flying
* Faster sprinting
* Side & Back jumps
* Charged jumps
* Wall jumping
* Head jumps
* Crawling
* Sliding

Exact behavior depends on configuration (see chapter 'Configuration' below)



Required Mods
=============

The ModLoader/MinecraftForge/MCPC+ installation package requires

    * either ModLoader and Player API vanilla 1.0 or higher
    * or Minecraft Forge and Player API forge 1.0 or higher

to be installed too. Additionally

    * Render Player API vanilla 1.0 or higher respectively
    * Render Player API forge 1.0 or higher

can be installed to improve the compatibiltity to other mods.


The standalone installation package does not need any other mods to be installed.



Installation
============

Installation varies depending on your minecraft installation.
So choose your package and install it - do NOT install more than one package.

In any case, NEVER forget: ALWAYS back up your stuff!


Standalone
----------
* Your minecraft installation does not use any mod management system.
* You don't care about other mods, you just want to smart move while playing Minecraft.

Copy all files and folders inside the installation package "Smart Moving Universal Standalone.zip" to their corresponding locations in your "Minecraft.jar" in the subfolder "bin" of your Minecraft installation folder.
Do not forget to delete the "META-INF" directory while you are at it.

The standalone package overwrites the files "aul.class", "bcw.class", "bex.class", "is.class", "jv".class and ka.class.

It should not be combined with other mods that overwrite any of these files.


ModLoader
---------
* You are allready playing Minecraft using Risugamis ModLoader.
* You you might want to install other mods in the future.

Move the Smart Moving installation package "Smart Moving Universal for ModLoader or Minecraft Forge or MCPC+.zip" into the subfolder "mods" of the mods folder of the Minecraft 1.6.4 version you want to install Smart Moving to.

Alternatively copy all files and folders inside this installation package to their corresponding locations in the Minecraft JAR file of the Minecraft 1.6.4 version you want to install Smart Moving to.

Do NOT use the Minecraft 1.6.4 version "1.6.4". This is the default version which will be redownloaded after every change of yours.

In case no other Minecraft 1.6.4 version is present, create a new one by copying the Minecraft 1.6.4 default version directory "1.6.4" to a new directory (for example: "1.6.4.modded"). Make sure you also change the names of the two copied files and the value of the property "id" inside the copied JSON file accordingly.

And don't forget to make sure there is no "META-INF" folder inside your modded JAR file anymore.

Don't forget to:
* ensure you have the mod Player API vanilla installed!
* ensure you have the latest version of Risugamis ModLoader installed!


Minecraft Forge
---------------
* You are allready playing Minecraft using Minecraft Forge
* You might want to install other mods in the future.

Move the Smart Moving installation package "Smart Moving Universal for ModLoader or Minecraft Forge or MCPC+.zip" into the subfolder "mods" of your Minecraft installation folder. In case this folder does not exist, install Minecraft Forge (http://www.minecraftforge.net) on your client and start the corresponding "Forge" Minecraft version at least once.

Don't forget to:
* ensure you have the mod Player API forge installed!
* ensure you have the latest version of Minecraft Forge installed!



Compatibility
=============

The ModLoader/MinecraftForge/MCPC+ installation package replaces specific previously created instances with proprietary ones:

* Server 'NetServerHandler' at "EntityPlayerMP.playerNetServerHandler"
  Client mods that use similar replacements will not work correctly with this client mod.



Configuration
=============

The file "smart_moving_options.txt" can be used to configure the behavior this mod.
It is located in your ".minecraft" folder next to minecrafts "options.txt".
If does not exist at Minecraft startup time it is automatically generated.

You can use its content to manipulate this mod's various features.

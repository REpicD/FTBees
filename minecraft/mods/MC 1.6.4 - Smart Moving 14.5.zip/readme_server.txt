=======================
Smart Moving Server Mod
=======================

Version 14.5 for Minecraft Server 1.6.4

by Divisor



Description
===========

The Smart Moving Server mod provides smart moving specific communication between different SMP clients.

Additionally using a SMP server with this mod avoids bugs that can happen when using Smart Moving clients with standard SMP servers.

In summary using a SMP server with Smart Moving provides the following features:
* crawling into small holes without taking damage
* climbing down without suffering ground arrival damage
* smart moving anmiations for the other players
* correct item placement while being small sized



Required Mods
=============

The ModLoader/MinecraftForge/MCPC+ installation package requires

    * Player API forge 1.0 or higher

respectively

    * Player API MCPC+  or higher

to be installed too.


The standalone installation package does not need any other mods to be installed.



Installation
============

Installation varies depending on the minecraft server you are using.
So choose your package and install it - do NOT install more than one package.

In any case, NEVER forget: ALWAYS back up your stuff!


Standalone Server
-----------------
* You are running a standard minecraft server
* Your minecraft server installation does not use any mod management system.
* You don't care about other mods, you just want to smart move while playing Minecraft.

Copy all files and folders inside the installation package "Smart Moving Universal Standalone.zip" to their corresponding locations in your "minecraft_server.1.6.4.jar".

The standalone package overwrites the files "aul.class", "bcw.class", "bex.class", "is.class", "jv".class and ka.class.

It should not be combined with other mods that overwrite any of these files.


Minecraft Forge Server
----------------------
* Your are running a standard minecraft server
* Your server allready has Minecraft Forge installed.

Move the Smart Moving installation package "Smart Moving Universal for ModLoader or Minecraft Forge or MCPC+.zip" into the subfolder "mods" of your Minecraft server installation folder.

Don't forget to:
* ensure you have the latest version of PlayerAPI forge installed!
* ensure you have the latest version of Minecraft Forge server installed!
* ensure all your clients have Minecraft Forge client installed!


MCPC+ Server
------------
* You are running a MCPC+ minecraft server.

When you don't allready have Player API installed on your MCPC+ server, install it. (http://www.minecraftforum.net/topic/738498-124api-player-api/)
You will need the Player API MCPC+ release for your MCPC+ server release. This specific Player API release has been build against the MCPC+ server release you are using.

After you successfully installed Player API MCPC+ for your specific MCPC+ release:
* Move the Smart Moving installation package "Smart Moving Universal for ModLoader or Minecraft Forge or MCPC+.zip" to the mods folder of your MCPC+ server.

Don't forget to:
* ensure you have a MCPC+ server release compatible to Minecraft 1.6.4.
* ensure you have a PlayerAPI MCPC+ release compatible to your specific MCPC+ server release.



Compatibility
=============

The ModLoader/MinecraftForge/MCPC+ installation package replaces specific previously created instances with proprietary ones:

* Server 'NetServerHandler' at "EntityPlayerMP.playerNetServerHandler"
  Server mods that use similar replacements will not work correctly with this Server mod.



Configuration
=============

The file "smart_moving_options.txt" can be used to configure the behavior this mod.
It is located in your minecraft server's working directory.
If does not exist at Minecraft server startup time it is automatically generated.

You can use its content to manipulate this mod's various features on all connected clients.



SBC Support
===========
Smart Moving provides support for Simple Block code (http://dev.bukkit.org/server-mods/sbc/)
Have a look at the website to find the exact codes to block specific Smart Moving features for server players.
